-- شغّل هذا النص مرة واحدة من SQL Editor داخل مشروع Supabase.
create table if not exists public.menu_data (
  id integer primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.menu_data enable row level security;

-- أنشئ Storage bucket عاماً لصور الأكلات.
insert into storage.buckets (id, name, public)
values ('menu-images', 'menu-images', true)
on conflict (id) do update set public = true;
