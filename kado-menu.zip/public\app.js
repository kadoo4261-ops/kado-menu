let menu;
const byId = id => document.getElementById(id);
const categoryIcon = '/assets/category-icon.svg';

async function load() {
  try { menu = await fetch('/api/menu').then(r => r.json()); render(); }
  catch { byId('empty').classList.remove('hidden'); byId('empty').textContent = 'تعذر تحميل المنيو حالياً.'; }
}
function foodCard(item) {
  const image = item.image ? `<img class="food-image" src="${item.image}" alt="${item.name}">` : '<div class="food-image no-image">🍽️</div>';
  return `<article class="card">${image}<div class="card-content"><h3>${item.name}</h3><p>${item.description || ''}</p><div class="price">${Number(item.price).toLocaleString('en-US')} د.ع</div></div></article>`;
}
function render() {
  byId('tagline').textContent = menu.restaurant.tagline;
  document.title = `${menu.restaurant.name} | المنيو`;
  if (!menu.categories.length) { byId('empty').classList.remove('hidden'); return; }
  byId('tabs').innerHTML = menu.categories.map(c => `<button onclick="choose('${c.id}')"><img src="${categoryIcon}" alt="">${c.name}</button>`).join('');
  byId('menuSections').innerHTML = menu.categories.map(c => {
    const items = menu.items.filter(i => i.categoryId === c.id && i.available);
    return `<section id="category-${c.id}"><h2 class="category-heading"><img src="${categoryIcon}" alt="">${c.name}</h2>${items.length ? `<div class="cards">${items.map(foodCard).join('')}</div>` : '<p class="empty">لا توجد أصناف ظاهرة في هذا القسم حالياً.</p>'}</section>`;
  }).join('');
  byId('empty').classList.add('hidden');
}
window.choose = id => document.getElementById(`category-${id}`).scrollIntoView({behavior:'smooth', block:'start'});
load();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js');
