const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const publicDir = path.join(root, 'public');
const dataFile = path.join(root, 'data', 'menu.json');
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)=(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
}
const adminPassword = process.env.KADO_ADMIN_PASSWORD || '783189';
const supabaseUrl = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const supabaseKey = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const cloudEnabled = Boolean(supabaseUrl && supabaseKey);
const sessions = new Set();
const mime = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'application/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.jpg':'image/jpeg', '.png':'image/png', '.svg':'image/svg+xml', '.webmanifest':'application/manifest+json' };

function localMenu() { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
function localSave(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }
function cloudHeaders(extra={}) { return {apikey:supabaseKey, Authorization:`Bearer ${supabaseKey}`, ...extra}; }
async function menu() {
  if (!cloudEnabled) return localMenu();
  const response = await fetch(`${supabaseUrl}/rest/v1/menu_data?id=eq.1&select=data`, {headers:cloudHeaders()});
  if (!response.ok) throw new Error('تعذر الاتصال بقاعدة البيانات');
  const rows = await response.json();
  if (rows[0]?.data) return rows[0].data;
  const initial = localMenu(); await save(initial); return initial;
}
async function uploadImage(value, itemId) {
  if (!value.startsWith('data:image/')) return value;
  const match = value.match(/^data:(image\/(png|jpeg|webp));base64,(.+)$/);
  if (!match) return '';
  const extension = match[2] === 'jpeg' ? 'jpg' : match[2];
  const objectPath = `foods/${itemId}-${Date.now()}.${extension}`;
  const response = await fetch(`${supabaseUrl}/storage/v1/object/menu-images/${objectPath}`, {method:'POST', headers:cloudHeaders({'Content-Type':match[1], 'x-upsert':'false'}), body:Buffer.from(match[3], 'base64')});
  if (!response.ok) throw new Error('تعذر رفع صورة الأكلة');
  return `${supabaseUrl}/storage/v1/object/public/menu-images/${objectPath}`;
}
async function save(data) {
  if (!cloudEnabled) return localSave(data);
  for (const item of data.items) item.image = await uploadImage(item.image, item.id);
  const response = await fetch(`${supabaseUrl}/rest/v1/menu_data?on_conflict=id`, {method:'POST', headers:cloudHeaders({'Content-Type':'application/json', Prefer:'resolution=merge-duplicates'}), body:JSON.stringify({id:1, data})});
  if (!response.ok) throw new Error('تعذر حفظ التعديلات في قاعدة البيانات');
}
function send(res, status, body, type='application/json; charset=utf-8') { res.writeHead(status, { 'Content-Type':type, 'Cache-Control':'no-store' }); res.end(type.includes('json') ? JSON.stringify(body) : body); }
function body(req) { return new Promise((resolve, reject) => { let value=''; req.on('data', c => { value += c; if(value.length > 8e6) req.destroy(); }); req.on('end', () => { try { resolve(value ? JSON.parse(value) : {}); } catch { reject(new Error('بيانات غير صالحة')); } }); }); }
function isAdmin(req) { const match = (req.headers.cookie || '').match(/kado_session=([^;]+)/); return Boolean(match && sessions.has(match[1])); }
function id() { return crypto.randomBytes(8).toString('hex'); }
function cleanImage(value) { return typeof value === 'string' && (value.startsWith('data:image/') || value.startsWith('/assets/') || value.startsWith('/uploads/')) ? value : ''; }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname === '/api/menu' && req.method === 'GET') return send(res, 200, await menu());
    if (url.pathname === '/api/login' && req.method === 'POST') {
      const input = await body(req);
      if (input.password !== adminPassword) return send(res, 401, {error:'كلمة المرور غير صحيحة'});
      const token = crypto.randomBytes(24).toString('hex'); sessions.add(token);
      res.writeHead(200, {'Content-Type':'application/json; charset=utf-8', 'Set-Cookie':`kado_session=${token}; HttpOnly; SameSite=Strict; Path=/`}); return res.end(JSON.stringify({ok:true}));
    }
    if (url.pathname === '/api/logout' && req.method === 'POST') { const token = ((req.headers.cookie||'').match(/kado_session=([^;]+)/)||[])[1]; if(token) sessions.delete(token); res.writeHead(200, {'Set-Cookie':'kado_session=; Max-Age=0; Path=/'}); return res.end(); }
    if (url.pathname === '/api/session' && req.method === 'GET') return send(res, 200, {authenticated:isAdmin(req)});
    if (url.pathname === '/api/setup' && req.method === 'POST') {
      if (cloudEnabled) return send(res, 403, {error:'تم إعداد الربط مسبقاً'});
      const input = await body(req);
      const projectUrl = String(input.projectUrl || '').replace(/\/$/, '');
      const secretKey = String(input.secretKey || '').trim();
      if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(projectUrl) || !/^sb_secret_/.test(secretKey)) return send(res, 400, {error:'تأكد من رابط المشروع والمفتاح السري'});
      fs.writeFileSync(envFile, `# إعدادات كادو المحلية — لا تشارك هذا الملف\nKADO_ADMIN_PASSWORD=${adminPassword}\nSUPABASE_URL=${projectUrl}\nSUPABASE_SECRET_KEY=${secretKey}\n`);
      return send(res, 200, {ok:true, message:'تم الحفظ. أعد تشغيل الموقع لتفعيل الربط.'});
    }
    if (url.pathname === '/api/menu' && req.method === 'PUT') {
      if (!isAdmin(req)) return send(res, 401, {error:'غير مصرح'});
      const input = await body(req);
      const categories = Array.isArray(input.categories) ? input.categories.map((c, index) => ({id:String(c.id||id()), name:String(c.name||'').trim().slice(0,50), order:index})).filter(c=>c.name) : [];
      const ids = new Set(categories.map(c=>c.id));
      const items = Array.isArray(input.items) ? input.items.map((i, index) => ({id:String(i.id||id()), categoryId:String(i.categoryId||''), name:String(i.name||'').trim().slice(0,80), description:String(i.description||'').trim().slice(0,300), price:Number(i.price)||0, image:cleanImage(i.image), available:i.available !== false, order:index})).filter(i=>i.name && ids.has(i.categoryId)) : [];
      await save({restaurant:{name:'كادو', tagline:String(input.restaurant?.tagline||'طعم يستاهل التجربة').slice(0,100)},categories,items}); return send(res,200,{ok:true});
    }
    if (url.pathname === '/setup' && cloudEnabled) return send(res, 404, 'Not found', 'text/plain');
    let filePath = url.pathname === '/admin' ? path.join(publicDir, 'admin.html') : path.join(publicDir, url.pathname === '/setup' ? 'setup.html' : url.pathname === '/' ? 'index.html' : url.pathname);
    filePath = path.normalize(filePath);
    if (!filePath.startsWith(publicDir)) return send(res, 403, 'Forbidden', 'text/plain');
    fs.readFile(filePath, (err, file) => err ? send(res,404,'Not found','text/plain') : (res.writeHead(200, {'Content-Type':mime[path.extname(filePath)] || 'application/octet-stream'}),res.end(file)));
  } catch (error) { send(res, 400, {error:error.message || 'تعذر تنفيذ الطلب'}); }
});
server.listen(process.env.PORT || 3000, () => console.log('KADO menu: http://localhost:3000'));
